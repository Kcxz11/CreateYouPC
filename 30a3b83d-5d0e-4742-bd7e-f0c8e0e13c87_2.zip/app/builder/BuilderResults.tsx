
'use client';

import { useState } from 'react';

interface Build {
  id: number;
  name: string;
  price: number;
  performance: number;
  components: {
    cpu: string;
    gpu: string;
    motherboard: string;
    ram: string;
    storage: string;
    psu: string;
    case: string;
  };
}

interface BuilderResultsProps {
  builds: Build[];
  onStartOver: () => void;
}

export default function BuilderResults({ builds, onStartOver }: BuilderResultsProps) {
  const [selectedBuild, setSelectedBuild] = useState<Build | null>(null);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Your AI-Generated PC Builds
        </h2>
        <p className="text-lg text-gray-600 mb-6">
          Here are the best builds our AI recommends based on your requirements
        </p>
        <button
          onClick={onStartOver}
          className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer"
        >
          ← Start Over
        </button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {builds.map((build, index) => (
          <div 
            key={build.id} 
            className={`bg-white rounded-xl shadow-lg p-6 border-2 transition-all duration-300 cursor-pointer hover:shadow-xl ${
              index === 0 ? 'border-blue-500 ring-2 ring-blue-200' : 'border-gray-200 hover:border-blue-300'
            }`}
            onClick={() => setSelectedBuild(build)}
          >
            {index === 0 && (
              <div className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium mb-4 inline-block">
                AI Recommended
              </div>
            )}
            
            <h3 className="text-xl font-bold text-gray-900 mb-2">{build.name}</h3>
            <div className="text-3xl font-bold text-blue-600 mb-4">${build.price.toLocaleString()}</div>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-600">Performance Score</span>
                <span className="text-sm font-bold text-gray-900">{build.performance}/100</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${build.performance}%` }}
                ></div>
              </div>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">CPU:</span>
                <span className="font-medium text-gray-900">{build.components.cpu}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">GPU:</span>
                <span className="font-medium text-gray-900">{build.components.gpu}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">RAM:</span>
                <span className="font-medium text-gray-900">{build.components.ram}</span>
              </div>
            </div>

            <button className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
              View Full Details
            </button>
          </div>
        ))}
      </div>

      {selectedBuild && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900">{selectedBuild.name}</h3>
                <button 
                  onClick={() => setSelectedBuild(null)}
                  className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-gray-700 cursor-pointer"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>

              <div className="space-y-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    ${selectedBuild.price.toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-600">
                    Performance Score: {selectedBuild.performance}/100
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-bold text-gray-900 mb-4">Complete Component List</h4>
                  <div className="space-y-3">
                    {Object.entries(selectedBuild.components).map(([key, value]) => (
                      <div key={key} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="font-medium text-gray-700 capitalize">
                          {key === 'cpu' ? 'Processor' : 
                           key === 'gpu' ? 'Graphics Card' : 
                           key === 'ram' ? 'Memory' : 
                           key === 'psu' ? 'Power Supply' : 
                           key === 'case' ? 'Case' : key}:
                        </span>
                        <span className="text-gray-900">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-4">
                  <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                    Save This Build
                  </button>
                  <button className="flex-1 border border-blue-600 text-blue-600 hover:bg-blue-50 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                    Share Build
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
