
'use client';

import { useState } from 'react';

interface BuilderFormProps {
  onSubmit: (data: any) => void;
  isLoading: boolean;
}

export default function BuilderForm({ onSubmit, isLoading }: BuilderFormProps) {
  const [formData, setFormData] = useState({
    budget: '1500',
    usage: 'gaming',
    experience: 'intermediate',
    language: 'english',
    preferences: {
      brand: 'no-preference',
      rgb: false,
      quiet: false,
      futureProof: true
    },
    requirements: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePreferenceChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        [field]: value
      }
    }));
  };

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8 text-center">
        <div className="animate-spin w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-6"></div>
        <h3 className="text-2xl font-bold text-gray-900 mb-4">AI is Analyzing Your Requirements</h3>
        <p className="text-gray-600">
          Our AI is processing thousands of components to create the perfect build for you. This will take just a moment...
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Budget Section */}
        <div className="space-y-6">
          <div>
            <label className="block text-lg font-semibold text-gray-900 mb-4">
              What's your budget?
            </label>
            <div className="space-y-4">
              {[
                { value: '800', label: '$800 - Budget Build', desc: 'Great for basic gaming and productivity' },
                { value: '1200', label: '$1,200 - Mid-Range Build', desc: 'Excellent 1080p gaming performance' },
                { value: '1800', label: '$1,800 - High-End Build', desc: '1440p gaming and content creation' },
                { value: '2500', label: '$2,500+ - Enthusiast Build', desc: '4K gaming and professional work' }
              ].map((option) => (
                <label key={option.value} className="flex items-start space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="budget"
                    value={option.value}
                    checked={formData.budget === option.value}
                    onChange={(e) => handleInputChange('budget', e.target.value)}
                    className="mt-1"
                  />
                  <div>
                    <div className="font-medium text-gray-900">{option.label}</div>
                    <div className="text-sm text-gray-600">{option.desc}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-lg font-semibold text-gray-900 mb-4">
              Primary Use Case
            </label>
            <div className="space-y-3">
              {[
                { value: 'gaming', label: 'Gaming', icon: 'ri-gamepad-line' },
                { value: 'productivity', label: 'Productivity & Office Work', icon: 'ri-briefcase-line' },
                { value: 'content-creation', label: 'Content Creation', icon: 'ri-video-line' },
                { value: 'programming', label: 'Programming & Development', icon: 'ri-code-line' },
                { value: 'general', label: 'General Use', icon: 'ri-computer-line' }
              ].map((option) => (
                <label key={option.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-50">
                  <input
                    type="radio"
                    name="usage"
                    value={option.value}
                    checked={formData.usage === option.value}
                    onChange={(e) => handleInputChange('usage', e.target.value)}
                  />
                  <div className="w-6 h-6 flex items-center justify-center">
                    <i className={`${option.icon} text-blue-600`}></i>
                  </div>
                  <span className="font-medium text-gray-900">{option.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Preferences Section */}
        <div className="space-y-6">
          <div>
            <label className="block text-lg font-semibold text-gray-900 mb-4">
              Language Preference
            </label>
            <div className="space-y-3">
              {[
                { value: 'english', label: 'English', flag: '🇺🇸' },
                { value: 'spanish', label: 'Español', flag: '🇪🇸' }
              ].map((option) => (
                <label key={option.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-50 border border-gray-200">
                  <input
                    type="radio"
                    name="language"
                    value={option.value}
                    checked={formData.language === option.value}
                    onChange={(e) => handleInputChange('language', e.target.value)}
                  />
                  <span className="text-xl">{option.flag}</span>
                  <span className="font-medium text-gray-900">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-lg font-semibold text-gray-900 mb-4">
              Experience Level
            </label>
            <div className="space-y-3">
              {[
                { value: 'beginner', label: 'Beginner', desc: 'First time building' },
                { value: 'intermediate', label: 'Intermediate', desc: 'Some building experience' },
                { value: 'expert', label: 'Expert', desc: 'Experienced builder' }
              ].map((option) => (
                <label key={option.value} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="experience"
                    value={option.value}
                    checked={formData.experience === option.value}
                    onChange={(e) => handleInputChange('experience', e.target.value)}
                  />
                  <div>
                    <div className="font-medium text-gray-900">{option.label}</div>
                    <div className="text-sm text-gray-600">{option.desc}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-lg font-semibold text-gray-900 mb-4">
              Preferences
            </label>
            <div className="space-y-4">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.preferences.rgb}
                  onChange={(e) => handlePreferenceChange('rgb', e.target.checked)}
                />
                <span>RGB Lighting & Aesthetics</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.preferences.quiet}
                  onChange={(e) => handlePreferenceChange('quiet', e.target.checked)}
                />
                <span>Quiet Operation</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.preferences.futureProof}
                  onChange={(e) => handlePreferenceChange('futureProof', e.target.checked)}
                />
                <span>Future-Proof Build</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-lg font-semibold text-gray-900 mb-4">
              Additional Requirements
            </label>
            <textarea
              value={formData.requirements}
              onChange={(e) => handleInputChange('requirements', e.target.value)}
              placeholder="Any specific requirements, games you want to play, or other details..."
              className="w-full p-4 border border-gray-300 rounded-lg resize-none text-sm"
              rows={4}
              maxLength={500}
            />
            <div className="text-sm text-gray-500 mt-2">
              {formData.requirements.length}/500 characters
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 text-center">
        <button
          type="submit"
          className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-4 rounded-lg text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg whitespace-nowrap cursor-pointer"
        >
          Generate My PC Build
        </button>
      </div>
    </form>
  );
}