
'use client';

import BuilderForm from './BuilderForm';
import BuilderResults from './BuilderResults';
import { useState } from 'react';

export default function BuilderPage() {
  const [buildData, setBuildData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFormSubmit = async (formData: any) => {
    setIsLoading(true);
    
    // Simulate AI processing
    setTimeout(() => {
      const mockBuilds = generateMockBuilds(formData);
      setBuildData(mockBuilds);
      setIsLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            AI PC Builder
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tell us about your needs and preferences, and our AI will create the perfect PC build for you.
          </p>
        </div>

        {!buildData ? (
          <BuilderForm onSubmit={handleFormSubmit} isLoading={isLoading} />
        ) : (
          <BuilderResults builds={buildData} onStartOver={() => setBuildData(null)} />
        )}
      </div>
    </div>
  );
}

function generateMockBuilds(formData: any) {
  const budget = parseInt(formData.budget);
  
  const builds = [
    {
      id: 1,
      name: 'AI Recommended Build',
      price: Math.floor(budget * 0.95),
      performance: 95,
      components: {
        cpu: budget > 1500 ? 'AMD Ryzen 7 7700X' : budget > 1000 ? 'AMD Ryzen 5 7600X' : 'AMD Ryzen 5 5600X',
        gpu: budget > 2000 ? 'NVIDIA RTX 4070 Ti' : budget > 1500 ? 'NVIDIA RTX 4060 Ti' : 'NVIDIA RTX 4060',
        motherboard: budget > 1500 ? 'ASUS ROG Strix B650-A' : 'MSI B550M Pro-A',
        ram: budget > 1500 ? '32GB DDR5-5600' : '16GB DDR4-3200',
        storage: budget > 1500 ? '1TB NVMe SSD + 2TB HDD' : '500GB NVMe SSD',
        psu: budget > 1500 ? '750W 80+ Gold' : '650W 80+ Bronze',
        case: 'Fractal Design Core 1000'
      }
    },
    {
      id: 2,
      name: 'Value Optimized Build',
      price: Math.floor(budget * 0.85),
      performance: 88,
      components: {
        cpu: budget > 1000 ? 'AMD Ryzen 5 5600X' : 'AMD Ryzen 5 4600G',
        gpu: budget > 1500 ? 'NVIDIA RTX 4060' : budget > 1000 ? 'NVIDIA RTX 3060' : 'AMD RX 6500 XT',
        motherboard: 'MSI B450M Pro-A',
        ram: '16GB DDR4-3200',
        storage: '500GB NVMe SSD',
        psu: '600W 80+ Bronze',
        case: 'Cooler Master MasterBox Q300L'
      }
    },
    {
      id: 3,
      name: 'Performance Focused Build',
      price: Math.floor(budget * 1.05),
      performance: 98,
      components: {
        cpu: budget > 2000 ? 'AMD Ryzen 9 7900X' : 'AMD Ryzen 7 7700X',
        gpu: budget > 2500 ? 'NVIDIA RTX 4080' : 'NVIDIA RTX 4070 Ti',
        motherboard: 'ASUS ROG Strix X670E-E',
        ram: '32GB DDR5-6000',
        storage: '2TB NVMe SSD Gen4',
        psu: '850W 80+ Gold',
        case: 'NZXT H7 Flow'
      }
    }
  ];

  return builds.filter(build => build.price <= budget * 1.1);
}
