
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function ExplorePage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedBudget, setSelectedBudget] = useState('all');

  const builds = [
    {
      id: 1,
      name: 'Ultimate Gaming Beast',
      category: 'gaming',
      budget: 'high',
      price: 2899,
      performance: 98,
      image: 'https://readdy.ai/api/search-image?query=High-end%20gaming%20PC%20with%20RGB%20lighting%2C%20multiple%20graphics%20cards%2C%20liquid%20cooling%20system%2C%20tempered%20glass%20case%2C%20colorful%20LED%20strips%2C%20professional%20product%20photography&width=400&height=300&seq=build1&orientation=landscape',
      specs: ['AMD Ryzen 9 7900X', 'RTX 4080 Super', '32GB DDR5', '2TB NVMe SSD'],
      description: 'Built for 4K gaming and streaming'
    },
    {
      id: 2,
      name: 'Content Creator Pro',
      category: 'content',
      budget: 'high',
      price: 2499,
      performance: 95,
      image: 'https://readdy.ai/api/search-image?query=Professional%20workstation%20PC%20setup%20with%20multiple%20monitors%2C%20video%20editing%20workspace%2C%20clean%20white%20and%20black%20color%20scheme%2C%20modern%20office%20environment&width=400&height=300&seq=build2&orientation=landscape',
      specs: ['AMD Ryzen 9 7900X', 'RTX 4070 Ti', '64GB DDR5', '4TB Storage'],
      description: 'Perfect for video editing and 3D rendering'
    },
    {
      id: 3,
      name: '1440p Gaming Champion',
      category: 'gaming',
      budget: 'mid',
      price: 1699,
      performance: 92,
      image: 'https://readdy.ai/api/search-image?query=Mid-range%20gaming%20PC%20build%20with%20blue%20and%20white%20color%20scheme%2C%20clean%20cable%20management%2C%20modern%20components%20visible%20through%20glass%20side%20panel&width=400&height=300&seq=build3&orientation=landscape',
      specs: ['AMD Ryzen 7 7700X', 'RTX 4070', '32GB DDR5', '1TB NVMe SSD'],
      description: 'Excellent 1440p gaming performance'
    },
    {
      id: 4,
      name: 'Budget Gaming Starter',
      category: 'gaming',
      budget: 'low',
      price: 899,
      performance: 85,
      image: 'https://readdy.ai/api/search-image?query=Budget-friendly%20gaming%20PC%20build%2C%20compact%20case%2C%20essential%20components%2C%20good%20value%20setup%2C%20clean%20and%20simple%20design%2C%20black%20case&width=400&height=300&seq=build4&orientation=landscape',
      specs: ['AMD Ryzen 5 5600X', 'RTX 4060', '16GB DDR4', '500GB NVMe SSD'],
      description: 'Great entry-level gaming build'
    },
    {
      id: 5,
      name: 'Productivity Powerhouse',
      category: 'productivity',
      budget: 'mid',
      price: 1299,
      performance: 88,
      image: 'https://readdy.ai/api/search-image?query=Professional%20office%20PC%20setup%2C%20clean%20workspace%2C%20business%20environment%2C%20multiple%20monitors%2C%20productivity-focused%20computer%20build&width=400&height=300&seq=build5&orientation=landscape',
      specs: ['Intel i7-13700', 'RTX 4060', '32GB DDR4', '1TB NVMe SSD'],
      description: 'Perfect for office work and multitasking'
    },
    {
      id: 6,
      name: 'Silent Workstation',
      category: 'productivity',
      budget: 'mid',
      price: 1499,
      performance: 90,
      image: 'https://readdy.ai/api/search-image?query=Silent%20PC%20build%20with%20large%20quiet%20fans%2C%20sound%20dampening%20case%2C%20minimal%20noise%20design%2C%20professional%20workstation%20setup&width=400&height=300&seq=build6&orientation=landscape',
      specs: ['AMD Ryzen 7 7700', 'RTX 4060 Ti', '32GB DDR5', '2TB Storage'],
      description: 'Ultra-quiet operation for professionals'
    }
  ];

  const categories = [
    { value: 'all', label: 'All Builds', icon: 'ri-computer-line' },
    { value: 'gaming', label: 'Gaming', icon: 'ri-gamepad-line' },
    { value: 'content', label: 'Content Creation', icon: 'ri-video-line' },
    { value: 'productivity', label: 'Productivity', icon: 'ri-briefcase-line' }
  ];

  const budgetRanges = [
    { value: 'all', label: 'All Budgets' },
    { value: 'low', label: 'Under $1,000' },
    { value: 'mid', label: '$1,000 - $2,000' },
    { value: 'high', label: '$2,000+' }
  ];

  const filteredBuilds = builds.filter(build => {
    const categoryMatch = selectedCategory === 'all' || build.category === selectedCategory;
    const budgetMatch = selectedBudget === 'all' || build.budget === selectedBudget;
    return categoryMatch && budgetMatch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Explore PC Builds
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Browse our curated collection of AI-optimized PC builds. Find inspiration or use these as starting points for your own build.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-4">Category</label>
              <div className="grid grid-cols-2 gap-3">
                {categories.map((category) => (
                  <button
                    key={category.value}
                    onClick={() => setSelectedCategory(category.value)}
                    className={`p-3 rounded-lg border-2 transition-all duration-200 flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
                      selectedCategory === category.value
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-blue-300 text-gray-700'
                    }`}
                  >
                    <div className="w-5 h-5 flex items-center justify-center">
                      <i className={category.icon}></i>
                    </div>
                    <span className="font-medium">{category.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-4">Budget Range</label>
              <div className="space-y-2">
                {budgetRanges.map((budget) => (
                  <label key={budget.value} className="flex items-center space-x-3 cursor-pointer">
                    <input
                      type="radio"
                      name="budget"
                      value={budget.value}
                      checked={selectedBudget === budget.value}
                      onChange={(e) => setSelectedBudget(e.target.value)}
                    />
                    <span className="font-medium text-gray-900">{budget.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Build Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBuilds.map((build) => (
            <div key={build.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:transform hover:scale-105 cursor-pointer">
              <img 
                src={build.image} 
                alt={build.name}
                className="w-full h-48 object-cover object-top"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{build.name}</h3>
                <p className="text-gray-600 mb-4">{build.description}</p>
                
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-2xl font-bold text-blue-600">${build.price.toLocaleString()}</span>
                    <span className="text-sm font-medium text-gray-600">Score: {build.performance}/100</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${build.performance}%` }}
                    ></div>
                  </div>
                </div>

                <div className="space-y-1 mb-6 text-sm">
                  {build.specs.map((spec, index) => (
                    <div key={index} className="text-gray-600">• {spec}</div>
                  ))}
                </div>

                <div className="flex space-x-3">
                  <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-semibold transition-colors text-sm whitespace-nowrap cursor-pointer">
                    View Details
                  </button>
                  <button className="flex-1 border border-blue-600 text-blue-600 hover:bg-blue-50 py-2 rounded-lg font-semibold transition-colors text-sm whitespace-nowrap cursor-pointer">
                    Customize
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredBuilds.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-search-line text-2xl text-gray-500"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">No builds found</h3>
            <p className="text-gray-600">Try adjusting your filters to see more results.</p>
          </div>
        )}

        <div className="mt-12 text-center">
          <Link 
            href="/builder" 
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg whitespace-nowrap cursor-pointer inline-block"
          >
            Create Your Own Build
          </Link>
        </div>
      </div>
    </div>
  );
}
