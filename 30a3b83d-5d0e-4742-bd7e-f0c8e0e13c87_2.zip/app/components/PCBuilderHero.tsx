
'use client';

import Link from 'next/link';

export default function PCBuilderHero() {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(15, 23, 42, 0.7), rgba(30, 41, 59, 0.8)), url('https://readdy.ai/api/search-image?query=Modern%20gaming%20computer%20setup%20with%20RGB%20lighting%2C%20high-end%20graphics%20card%2C%20multiple%20monitors%2C%20sleek%20black%20desk%20setup%2C%20futuristic%20tech%20workspace%2C%20dark%20ambient%20lighting%20with%20blue%20and%20purple%20accents%2C%20professional%20product%20photography%20style%2C%20clean%20minimalist%20background&width=1920&height=1080&seq=hero-bg&orientation=landscape')`
      }}
    >
      <div className="w-full max-w-7xl mx-auto px-6 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Build Your Perfect PC with
            <span className="text-blue-400 block mt-2">AI Intelligence</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200 leading-relaxed">
            Get personalized PC builds tailored to your budget, preferences, and compatibility requirements. 
            Our AI analyzes thousands of components to create the perfect setup for you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link 
              href="/builder" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg whitespace-nowrap cursor-pointer"
            >
              Start Building Now
            </Link>
            <Link 
              href="/explore" 
              className="border-2 border-white text-white hover:bg-white hover:text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 whitespace-nowrap cursor-pointer"
            >
              Explore Builds
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
