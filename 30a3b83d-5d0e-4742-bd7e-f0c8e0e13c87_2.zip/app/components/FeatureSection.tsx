
'use client';

export default function FeatureSection() {
  const features = [
    {
      icon: 'ri-brain-line',
      title: 'AI-Powered Recommendations',
      description: 'Advanced algorithms analyze performance data and compatibility to suggest optimal components for your needs.'
    },
    {
      icon: 'ri-money-dollar-circle-line',
      title: 'Budget Optimization',
      description: 'Get the best performance within your budget range. Smart allocation across components for maximum value.'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Compatibility Guaranteed',
      description: 'Never worry about incompatible parts. Our system ensures all components work together perfectly.'
    },
    {
      icon: 'ri-speed-line',
      title: 'Performance Focused',
      description: 'Builds optimized for gaming, content creation, productivity, or any specific use case you have in mind.'
    },
    {
      icon: 'ri-time-line',
      title: 'Real-Time Pricing',
      description: 'Live price tracking from multiple retailers to find the best deals and availability.'
    },
    {
      icon: 'ri-customer-service-2-line',
      title: 'Expert Support',
      description: 'Access to PC building guides, installation tips, and community support throughout your build.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Why Choose Our AI Builder?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Experience the future of PC building with intelligent recommendations, 
            perfect compatibility, and unmatched value optimization.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-gray-50 p-8 rounded-xl hover:shadow-lg transition-all duration-300 hover:transform hover:scale-105 cursor-pointer">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <i className={`${feature.icon} text-2xl text-blue-600`}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
