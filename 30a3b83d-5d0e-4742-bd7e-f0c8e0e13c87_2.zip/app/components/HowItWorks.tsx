
'use client';

export default function HowItWorks() {
  const steps = [
    {
      step: '01',
      title: 'Set Your Parameters',
      description: 'Tell us your budget, intended use, and any specific preferences or requirements you have.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20computer%20interface%20showing%20budget%20slider%20and%20preference%20selection%20form%2C%20clean%20UI%20design%20with%20blue%20accents%2C%20professional%20software%20interface%2C%20minimal%20background%20with%20subtle%20tech%20elements&width=400&height=300&seq=step1&orientation=landscape'
    },
    {
      step: '02',
      title: 'AI Analysis',
      description: 'Our AI analyzes thousands of components, prices, and compatibility data to create optimal builds.',
      image: 'https://readdy.ai/api/search-image?query=Abstract%20AI%20brain%20processing%20data%20with%20computer%20components%20floating%20around%2C%20neural%20network%20visualization%2C%20blue%20and%20purple%20tech%20background%2C%20futuristic%20digital%20analysis%20concept&width=400&height=300&seq=step2&orientation=landscape'
    },
    {
      step: '03',
      title: 'Get Recommendations',
      description: 'Receive multiple build options ranked by performance, value, and compatibility with detailed explanations.',
      image: 'https://readdy.ai/api/search-image?query=Computer%20screen%20displaying%20PC%20build%20comparison%20chart%20with%20components%20list%2C%20performance%20graphs%2C%20price%20comparison%2C%20clean%20modern%20interface%20design%20with%20organized%20layout&width=400&height=300&seq=step3&orientation=landscape'
    },
    {
      step: '04',
      title: 'Build & Enjoy',
      description: 'Follow our step-by-step assembly guide and enjoy your perfectly optimized PC build.',
      image: 'https://readdy.ai/api/search-image?query=Person%20assembling%20computer%20components%20on%20clean%20workspace%2C%20installing%20graphics%20card%20into%20motherboard%2C%20professional%20build%20environment%2C%20good%20lighting%2C%20focused%20hands%20working&width=400&height=300&seq=step4&orientation=landscape'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            How It Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Building your perfect PC has never been easier. Follow these simple steps 
            to get AI-powered recommendations tailored specifically for you.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {steps.map((step, index) => (
            <div key={index} className="flex flex-col md:flex-row items-center gap-8">
              <div className="flex-shrink-0">
                <img 
                  src={step.image} 
                  alt={step.title}
                  className="w-80 h-60 object-cover rounded-xl shadow-lg"
                />
              </div>
              <div className="flex-1">
                <div className="text-6xl font-bold text-blue-200 mb-4">{step.step}</div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{step.title}</h3>
                <p className="text-gray-600 text-lg leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
