
'use client';

import Link from 'next/link';
import PCBuilderHero from './components/PCBuilderHero';
import FeatureSection from './components/FeatureSection';
import HowItWorks from './components/HowItWorks';
import CallToAction from './components/CallToAction';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <PCBuilderHero />
      <FeatureSection />
      <HowItWorks />
      <CallToAction />
    </div>
  );
}
